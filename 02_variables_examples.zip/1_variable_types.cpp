// s. trowbridge 2024
#include <iostream>
using namespace std;

int main() {
    cout << "\n";

    string s = "1";         // string
    int i = 1;              // integer
    float f = 1.0;          // floating point
    char c = '1';           // character
    bool b = true;          // boolean 

    cout << s << "\n";
    cout << i << "\n";
    cout << f << "\n";
    cout << c << "\n";
    cout << b << "\n\n";

    cout << "\n";
    return 0;
}
