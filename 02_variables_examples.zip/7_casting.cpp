// s. trowbridge 2024
#include <iostream>
using namespace std;

int main() {
    cout << endl;

    int i = 'A';            // casting: convert a copy of the char 'A' into the integer 65, then store in i
    cout << i << "\n";

    char c = 65;            // casting: convert a copy of the integer 65 into the char 'A', then store into c
    cout << c << "\n";

    float f = 5;            // casting: convert a copy of the integer 5 to the float 5.0, then store into f
    cout << f << "\n";

    cout << endl;
    return 0;
}