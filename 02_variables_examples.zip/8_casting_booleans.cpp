// s. trowbridge 2024
#include <iostream>
using namespace std;

int main() {
    cout << endl;

    bool b1 = 20;           // casting: non zero values convert to true
    cout << b1 << "\n";

    bool b2 = 0;            // casting: zero values convert to false
    cout << b2 << "\n";    

    cout << endl;
    return 0;
}