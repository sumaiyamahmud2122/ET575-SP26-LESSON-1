// s. trowbridge 2024
#include <iostream>
using namespace std;

int main() {
    cout << endl;

    int i;          // declare          (allocate memory)
    i = 5;          // assignment       (store a value at specfied location)
    int j = 10;     // initialization   (allocate memory and store value at that location)

    cout << endl;
    return 0;
}

