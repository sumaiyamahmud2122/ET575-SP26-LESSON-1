// s. trowbridge 2024
#include <iostream>
using namespace std;

int main() {
    cout << endl;

    //string s = 5;         // compiler error an integer literal cannot be stored into a string

    //int i = "Hi";         // compiler error: a string literal cannot be stared in an integer

    cout << endl;
    return 0;
}

