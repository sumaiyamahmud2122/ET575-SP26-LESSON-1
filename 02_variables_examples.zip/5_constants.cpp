// s. trowbridge 2024
#include <iostream>
using namespace std;

int main() {
    cout << endl;

    const float NY_TAX_RATE = .08875;   // constant: a variable whose value cannot change

    //NY_TAX_RATE = .088888;              // compiler error

    cout << endl;
    return 0;
}

